﻿using System.Diagnostics;

var builder = WebApplication.CreateBuilder(args);

// Standard razor stuff
builder.Services.AddRazorPages();
var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();

// Upload folder
var fileStorageRoot = Path.GetFullPath("c:\\temp\\uploads");
Directory.CreateDirectory(fileStorageRoot);

app.MapPost("/upload", async (HttpRequest req) =>
{
    if (!req.HasFormContentType)
    {
        return Results.Json(new { success = false, message = "Invalid form data" });
    }

    var form = await req.ReadFormAsync();
    var file = form.Files["file"];

    if (file == null || file.Length == 0)
    {
        return Results.Json(new { success = false, message = "No file uploaded" });
    }

    if (!IsValidFile(file.FileName, file.Length, out var errorMessage))
    {
        return Results.Json(new { success = false, message = errorMessage });
    }

    // Generate safe filename
    var safeFileName = GetSafeFileName(file.FileName);
    var uniqueId = Guid.NewGuid().ToString("N")[..8];
    var fileName = $"{Path.GetFileNameWithoutExtension(safeFileName)}_{uniqueId}{Path.GetExtension(safeFileName)}";
    var destination = Path.Combine(fileStorageRoot, fileName);

    try
    {
        // Save the file
        using (var fileStream = new FileStream(destination, FileMode.Create))
        {
            await file.CopyToAsync(fileStream);
        }

        Console.WriteLine($"File saved successfully: {destination}");
        return Results.Json(new { success = true, fileName = fileName, path = destination });
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error saving file: {ex.Message}");
        return Results.Json(new { success = false, message = $"Error saving file: {ex.Message}" });
    }
});

app.Run();

static bool IsValidFile(string fileName, long fileSize, out string reason)
{
    reason = "";

    if (string.IsNullOrWhiteSpace(fileName))
    {
        reason = "No filename provided";
        return false;
    }

    // Check for path traversal attempts
    if (fileName.Contains("..") || fileName.Contains("/") || fileName.Contains("\\"))
    {
        reason = "Invalid filename";
        return false;
    }

    
    const long maxFileSize = 20 * 1024 * 1024; 
    if (fileSize > maxFileSize)
    {
        reason = $"File too large. Maximum size is {maxFileSize / 1024 / 1024}MB";
        return false;
    }

    return true;
}

static string GetSafeFileName(string fileName)
{
    var name = Path.GetFileName(fileName);
    
    // Remove any invalid characters
    foreach (var invalidChar in Path.GetInvalidFileNameChars())
    {
        name = name.Replace(invalidChar, '_');
    }

    return string.IsNullOrWhiteSpace(name) ? "file" : name;
}
